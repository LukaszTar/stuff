from utitilies.custom_logger import custom_logger
from base.selenium_driver import SeleniumDriver


class Status(SeleniumDriver):

    def __init__(self, driver):
        super(Status, self).__init__(driver)
        self.result_list = []
        self.log = custom_logger()

    def set_result(self, result, result_message):
        try:
            if result is not None:
                if result:
                    self.result_list.append("PASS")
                    self.log.info("### VERIFICATION SUCCESSFUL ### " + result_message)
                else:
                    self.result_list.append("FAIL")
                    self.save_screenshots(result_message)
                    self.log.info("### VERIFICATION FAILED ### " + result_message)
            else:
                self.result_list.append("FAIL")
                self.save_screenshots(result_message)
                self.log.info("### VERIFICATION FAILED ### " + result_message)
        except:
            self.result_list.append("FAIL")
            self.save_screenshots(result_message)
            self.log.info("### Exception Occurred !!! ###")

    def mark(self, result, result_message):
        self.set_result(result, result_message)

    def mark_final(self, test_name):
        if "FAIL" in self.result_list:
            self.log.error('### VERIFICATION FAILED ### ' + test_name)
            self.result_list.clear()
            assert 0
        else:
            self.log.info('### VERIFICATION PASSED ### ' + test_name)
            self.result_list.clear()
