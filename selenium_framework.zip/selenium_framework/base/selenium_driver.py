from selenium.webdriver.common.by import By
from selenium.webdriver.common.action_chains import ActionChains


class SeleniumDriver:
    """Wrapper class for selenium"""
    def __init__(self, driver):
        self.driver = driver

    def get_by_type(self, locator_type):
        locator_type = locator_type.lower()
        if locator_type.lower() == 'id':
            return By.XPATH
        elif locator_type.lower() == 'xpath':
            return By.XPATH
        elif locator_type.lower() == 'name':
            return By.NAME
        elif locator_type.lower() == 'class':
            return By.CLASS_NAME
        elif locator_type.lower() == 'link':
            return By.LINK_TEXT
        elif locator_type.lower() == 'css':
            return By.CSS_SELECTOR
        elif locator_type.lower() == 'partial_link':
            return By.PARTIAL_LINK_TEXT
        elif locator_type.lower() == 'tag':
            return By.TAG_NAME
        else:
            print('Incorrect locator type')
        return False

    def get_element(self, locator, locator_type='id'):
        element = None
        try:
            by_type = self.get_by_type(locator_type)
            element = self.driver.find_element(by_type, locator)
            print('Element found with locator: {} and locator id: {}'.format(locator, locator_type))
            return element
        except:
            print('Element not found with locator: {} and locator id: {}'.format(locator, locator_type))
            return element

    def mouse_hover(self, locator, locator_type='id'):
        try:
            element = self.get_element(locator, locator_type)
            action = ActionChains(self.driver)
            action.move_to_element(element).perform()
            print('Mouseover to element with locator: {} and locator id: {}'.format(locator, locator_type))
        except:
            print('Could not mouseover to element with locator: {} and locator id: {}'.format(locator, locator_type))
