import pytest
import unittest
from pages.login.login_page import LoginPage

@pytest.mark.usefixtures('class_level_fixture')
class TestLoginPage(unittest.TestCase):

    def test_valid_login(self):
        self.lp = LoginPage(self.driver)
        self.lp.hover_to_login_icon()
