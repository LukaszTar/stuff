from pages.home.home_page import HomePage
from pages.register.register_page import RegisterPage
from utitilies.read_csv import read_data_from_csv
from ddt import ddt, data, unpack
import unittest
import pytest


@pytest.mark.usefixtures('class_level_fixture')
@ddt
class TestRegister(unittest.TestCase):

    @pytest.fixture(autouse=True)
    def custom_setup(self):
        self.rp = RegisterPage(self.driver)
        self.hp = HomePage(self.driver)
        yield
        self.hp.go_to_home_page()

    @pytest.mark.run(order=1)
    @data(*read_data_from_csv('/home/lukasz/Pulpit/selenium_framework/selenium_framework/register_user_data.csv'))
    @unpack
    def test_invalid_register_empty_form(self, name, last_name, password, email, accept_terms):
        self.hp.go_to_register_page()
        status = self.rp.register(name, last_name, password, email, accept_terms)
        status.mark_final(
            'test_invalid_register_empty_form name:{}, last_name:{}, password:{}, email:{}, accept_terms:{}\n\n'.format(name, last_name, password, email, accept_terms))
