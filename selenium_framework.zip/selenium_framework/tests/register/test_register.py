from pages.home.home_page import HomePage
from pages.register.register_page import RegisterPage
from utitilies.read_csv import read_data_from_csv
from utitilies.status import Status
from ddt import ddt, data, unpack
import unittest
import pytest


@pytest.mark.usefixtures('class_level_fixture')
@ddt
class TestRegister(unittest.TestCase):

    @pytest.fixture(autouse=True)
    def custom_setup(self):
        self.rp = RegisterPage(self.driver)
        self.hp = HomePage(self.driver)
        self.st = Status(self.driver)
        yield
        self.hp.go_to_home_page()

    @pytest.mark.run(order=1)
    @data(*read_data_from_csv('/home/lukasz/Pulpit/selenium_framework/selenium_framework/register_user_data.csv'))
    @unpack
    def test_invalid_register_empty_form(self, name, last_name, password, email, accept_terms):
        self.hp.go_to_register_page()
        self.rp.fill_register_form(name, last_name, password, email, accept_terms)
        self.rp.click_on_register_button()
        name_textbox_status = self.rp.verify_name(name)
        self.st.mark(name_textbox_status, 'Verify textbox for "Imię"'.format(name))
        last_name_status = self.rp.verify_last_name(last_name)
        self.st.mark(last_name_status, 'Verify textbox for "Nazwisko"'.format(last_name))
        email_status = self.rp.verify_email(email)
        self.st.mark(email_status, 'Verify textbox for "Adres e-mail"'.format(email))
        password_status = self.rp.verify_password(password)
        self.st.mark(password_status, 'Verify textbox for "Hasło"'.format(password))
        accept_terms_status = self.rp.verify_accept_terms(accept_terms)
        self.st.mark(accept_terms_status, 'Verify checkbox for accept terms'.format(accept_terms))
        self.st.mark_final(
            'test_invalid_register_empty_form name:{}, last_name:{}, password:{}, email:{}, accept_terms:{}\n\n'.format(name, last_name, password, email, accept_terms))
