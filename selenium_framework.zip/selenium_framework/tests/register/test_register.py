from pages.home.home_page import HomePage
from pages.register.register_page import RegisterPage
from utitilies.read_csv import read_data_from_csv
from ddt import ddt, data, unpack
import unittest
import pytest


@pytest.mark.usefixtures('class_level_fixture')
@ddt
class TestRegister(unittest.TestCase):

    @pytest.fixture(autouse=True)
    def custom_setup(self):
        self.rp = RegisterPage(self.driver)
        self.hp = HomePage(self.driver)
        yield
        self.hp.go_to_home_page()

    @pytest.mark.run(order=1)
    @data(*read_data_from_csv('/home/lukasz/Pulpit/selenium_framework/selenium_framework/register_user_data.csv'))
    @unpack
    def test_invalid_register_empty_form(self, name, last_name, password, email, accept_terms):
        self.hp.go_to_register_page()
        self.rp.register(name, last_name, password, email, accept_terms)

    # @pytest.mark.run(order=2)
    # def test_invalid_register_empty_name(self):
    #     self.hp.go_to_register_page()
    #     self.rp.register(name='', last_name='targonsk', password='abcabc', email='test@email.com', accept_terms=True)
    #
    # @pytest.mark.run(order=3)
    # def test_invalid_register_empty_last_name(self):
    #     self.hp.go_to_register_page()
    #     self.rp.register(name='Lukasz', last_name='', password='abcabc', email='test@email.com', accept_terms=True)
    #
    # @pytest.mark.run(order=4)
    # def test_invalid_register_empty_password(self):
    #     self.hp.go_to_register_page()
    #     self.rp.register(name='Lukasz', last_name='Targonski', password='', email='test@email.com', accept_terms=True)
    #
    # @pytest.mark.run(order=5)
    # def test_invalid_register_empty_email(self):
    #     self.hp.go_to_register_page()
    #     self.rp.register(name='Lukasz', last_name='Targonski', password='abcabc', email='', accept_terms=True)
    #
    # @pytest.mark.run(order=6)
    # def test_invalid_register_terms_unchecked(self):
    #     self.hp.go_to_register_page()
    #     self.rp.register(name='Lukasz', last_name='Targonski', password='abcabc', email='asd@sda.pl', accept_terms=False)
    #
    # @pytest.mark.run(order=7)
    # def test_invalid_register_incorrect_email(self):
    #     self.hp.go_to_register_page()
    #     self.rp.register(name='Lukasz', last_name='Targonski', password='abcabc', email='asd@sda', accept_terms=True)
    #
    # @pytest.mark.run(order=8)
    # def test_invalid_register_incorrect_password(self):
    #     self.hp.go_to_register_page()
    #     self.rp.register(name='Lukasz', last_name='Targonski', password='abc', email='asd@sda.pl', accept_terms=True)
