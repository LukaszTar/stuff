from pages.home.home_page import HomePage
from pages.register.register_page import RegisterPage
import unittest
import pytest


@pytest.mark.usefixtures('class_level_fixture')
class TestRegister(unittest.TestCase):

    @pytest.fixture(autouse=True)
    def custom_setup(self):
        self.rp = RegisterPage(self.driver)
        self.hp = HomePage(self.driver)

    @pytest.mark.run(order=1)
    def test_invalid_register_empty_form(self):
        self.hp.go_to_register_page()
        self.rp.register(name='', last_lame='', password='', email='')
        self.rp.verify_empty_name_message()
        self.rp.verify_empty_last_name_message()
        self.rp.verify_empty_email_message()
        self.rp.verify_empty_password_message()
        self.rp.go_to_previous_page()

    @pytest.mark.run(order=2)
    def test_invalid_register_empty_name(self):
        self.hp.go_to_register_page()
        self.rp.register(name='', last_lame='targonsk', password='abcabc', email='test@email.com')
        self.rp.verify_empty_name_message()
        self.rp.go_to_previous_page()

    @pytest.mark.run(order=3)
    def test_invalid_register_empty_last_name(self):
        self.hp.go_to_register_page()
        self.rp.register(name='Lukasz', last_lame='', password='abcabc', email='test@email.com')
        self.rp.verify_empty_last_name_message()
        self.rp.go_to_previous_page()

    @pytest.mark.run(order=4)
    def test_invalid_register_empty_password(self):
        self.hp.go_to_register_page()
        self.rp.register(name='Lukasz', last_lame='Targonski', password='', email='test@email.com')
        self.rp.verify_empty_password_message()
        self.rp.go_to_previous_page()

    @pytest.mark.run(order=5)
    def test_invalid_register_empty_email(self):
        self.hp.go_to_register_page()
        self.rp.register(name='Lukasz', last_lame='Targonski', password='abcabc', email='')
        self.rp.verify_empty_email_message()
        self.rp.go_to_previous_page()
