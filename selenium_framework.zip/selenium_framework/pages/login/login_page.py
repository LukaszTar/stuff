from base.selenium_driver import SeleniumDriver


class LoginPage(SeleniumDriver):
    def __init__(self, driver):
        self.driver = driver
        super().__init__(driver)

    def hover_to_login_icon(self):
        self.mouse_hover("//div[@class='name']", locator_type='xpath')