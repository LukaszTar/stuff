from base.selenium_driver import SeleniumDriver


class RegisterPage(SeleniumDriver):

    _name_testbox = 'firstName'
    _empty_name_message = "//span[contains(text(), 'Podaj imię.')]"
    _last_name_testboc = 'lastName'
    _empty_last_name_message = "//span[contains(text(), 'Podaj nazwisko.')]"
    _email_textbox = 'email'
    _empty_email_message = "//span[contains(text(), 'Podaj adres e-mail.')]"
    _password_textbox = 'password'
    _empty_password_message = "//span[contains(text(), 'Podaj hasło.')]"
    _register_button = "//button[@type='submit']"

    def __init__(self, driver):
        self.driver = driver
        super().__init__(driver)

    def enter_name(self, name):
        self.element_send_keys(name, self._name_testbox, locator_type='id')

    def enter_last_name(self, last_name):
        self.element_send_keys(last_name, self._last_name_testboc, locator_type='id')

    def enter_password(self, password):
        self.element_send_keys(password, self._password_textbox, locator_type='id')

    def enter_email(self, email):
        self.element_send_keys(email, self._email_textbox, locator_type='id')

    def fill_register_form(self, name='', last_lame='', password='', email=''):
        self.enter_name(name)
        self.enter_last_name(last_lame)
        self.enter_email(email)
        self.enter_password(password)

    def click_on_register_button(self):
        self.element_click(self._register_button, locator_type='xpath')

    def register(self, name='', last_lame='', password='', email=''):
        self.fill_register_form(name, last_lame, password, email)
        self.click_on_register_button()

    def verify_empty_name_message(self):
        empty_name_message_exsists = self.is_element_visible(self._empty_name_message, locator_type='xpath')
        assert empty_name_message_exsists==True,'Cannot find "Podaj imie." message'

    def verify_empty_last_name_message(self):
        empty_name_message_exsists = self.is_element_visible(self._empty_last_name_message, locator_type='xpath')
        assert empty_name_message_exsists==True,'Cannot find "Podaj nazwisko." message'

    def verify_empty_email_message(self):
        empty_name_message_exsists = self.is_element_visible(self._empty_email_message, locator_type='xpath')
        assert empty_name_message_exsists==True,'Cannot find "Podaj adres e-mail." message'

    def verify_empty_password_message(self):
        empty_name_message_exsists = self.is_element_visible(self._empty_password_message, locator_type='xpath')
        assert empty_name_message_exsists==True,'Cannot find "Podaj haslo." message'