from base.selenium_driver import SeleniumDriver
from utitilies.status import Status
import re


class RegisterPage(SeleniumDriver):

    _name_testbox = 'firstName'
    _empty_name_message = "//span[contains(text(), 'Podaj imię.')]"
    _last_name_testboc = 'lastName'
    _empty_last_name_message = "//span[contains(text(), 'Podaj nazwisko.')]"
    _email_textbox = 'email'
    _empty_email_message = "//span[contains(text(), 'Podaj adres e-mail.')]"
    _incorrect_email_address = "//span[contains(text(), 'Podaj prawidłowy adres e-mail.')]"
    _too_short_password_message = "//span[contains(text(), 'Hasło powinno mieć minimum 6 znaków.')]"
    _password_textbox = 'password'
    _empty_password_message = "//span[contains(text(), 'Podaj hasło.')]"
    _register_button = "//button[@type='submit']"
    _empty_terms_checkbox = "//span[contains(text(), 'Zaakceptuj regulamin.')]"
    _accept_terms_checkbox = "termsOfUseAcceptation"
    _marked_invalid_textbox = "div[contains(@class, 'invalid')]"
    _marked_valid_textbox = "div[@class='marked valid']"

    def __init__(self, driver):
        self.driver = driver
        super().__init__(driver)
        self.st = Status(driver)

    def enter_name(self, name):
        self.element_send_keys(name, self._name_testbox, locator_type='id')

    def enter_last_name(self, last_name):
        self.element_send_keys(last_name, self._last_name_testboc, locator_type='id')

    def enter_password(self, password):
        self.element_send_keys(password, self._password_textbox, locator_type='id')

    def enter_email(self, email):
        self.element_send_keys(email, self._email_textbox, locator_type='id')

    def accept_terms_checkbox(self):
        self.element_click(self._accept_terms_checkbox, locator_type='id')

    def click_on_register_button(self):
        self.element_click(self._register_button, locator_type='xpath')

    def verify_valid_form(self, locator, message_locator):
        marked_valid_form = self.is_element_present("//input[contains(@id, '{}')]".format(locator)+'/parent::'+self._marked_valid_textbox, locator_type='xpath')
        self.st.mark(marked_valid_form, 'Textbox for {} should be marked as valid'.format(locator))

        incorrect_form_message = self.is_element_visible(message_locator, locator_type='xpath')
        self.st.mark(not incorrect_form_message, 'Incorrect form message should not be displayed')

    def verify_empty_name_message(self):
        empty_name_message_exsists = self.is_element_visible(self._empty_name_message, locator_type='xpath')
        self.st.mark(empty_name_message_exsists, '"Podaj imie." message should be displayed')

    def verify_empty_last_name_message(self):
        empty_name_message_exsists = self.is_element_visible(self._empty_last_name_message, locator_type='xpath')
        self.st.mark(empty_name_message_exsists, '"Podaj nazwisko." message should be displayed')

    def verify_empty_email_message(self):
        empty_name_message_exsists = self.is_element_visible(self._empty_email_message, locator_type='xpath')
        self.st.mark(empty_name_message_exsists, '"Podaj adres e-mail." message should be displayed')

    def verify_incorrect_email_address_message(self):
        incorrect_email_message_exists = self.is_element_visible(self._incorrect_email_address, locator_type='xpath')
        self.st.mark(incorrect_email_message_exists, '"Podaj prawidłowy adres e-mail." message should be displayed')

    def verify_email(self, email):
        result = re.match('^[_a-z0-9-]+(\\.[_a-z0-9-]+)*@[a-z0-9-]+(\\.[a-z0-9-]+)*(\\.[a-z]{2,4})$', email)
        print(result)
        if not result:
            self.verify_incorrect_email_address_message()
        else:
            self.verify_valid_form(self._email_textbox, self._empty_email_message)

    def verify_too_short_password_message(self):
        too_short_password_message = self.is_element_visible(self._too_short_password_message, locator_type='xpath')
        self.st.mark(too_short_password_message, '"Hasło powinno mieć minimum 6 znaków." message should be displayed')

    def verify_empty_password_message(self):
        empty_name_message_exsists = self.is_element_visible(self._empty_password_message, locator_type='xpath')
        self.st.mark(empty_name_message_exsists, '"Podaj haslo." message should be displayed')

    def verify_empty_tersm_message(self):
        empty_terms_message_exsists = self.is_element_visible(self._empty_terms_checkbox, locator_type='xpath')
        self.st.mark(empty_terms_message_exsists, '"Zaakceptuj regulamin." message should be displayed')

    def verify_form_fields_message(self, name='', last_name='', password='', email='', accept_terms=False):
        if not name:
            self.verify_empty_name_message()
        else:
            self.verify_valid_form(self._name_testbox, self._empty_name_message)

        if not last_name:
            self.verify_empty_last_name_message()
        else:
            self.verify_valid_form(self._last_name_testboc, self._empty_last_name_message)

        if not password:
            self.verify_empty_password_message()
        elif len(password) < 6:
            self.verify_too_short_password_message()
        else:
            self.verify_valid_form(self._password_textbox, self._empty_password_message)

        if not email:
            self.verify_empty_email_message()
        else:
            self.verify_email(email)

        if not accept_terms:
            self.verify_empty_tersm_message()

        return self.st

    def fill_register_form(self, name='', last_name='', password='', email='', accept_terms=False):
        self.enter_name(name)
        self.enter_last_name(last_name)
        self.enter_email(email)
        self.enter_password(password)
        if accept_terms:
            self.accept_terms_checkbox()

    def register(self, name='', last_name='', password='', email='', accept_terms=False):
        self.fill_register_form(name, last_name, password, email, accept_terms)
        self.click_on_register_button()
        return self.verify_form_fields_message(name, last_name, password, email, accept_terms)
