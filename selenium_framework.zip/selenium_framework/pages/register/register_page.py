from base.selenium_driver import SeleniumDriver
import re

class RegisterPage(SeleniumDriver):

    _name_testbox = 'firstName'
    _empty_name_message = "//span[contains(text(), 'Podaj imię.')]"
    _last_name_testboc = 'lastName'
    _empty_last_name_message = "//span[contains(text(), 'Podaj nazwisko.')]"
    _email_textbox = 'email'
    _empty_email_message = "//span[contains(text(), 'Podaj adres e-mail.')]"
    _incorrect_email_address = "//span[contains(text(), 'Podaj prawidłowy adres e-mail.')]"
    _too_short_password_message = "//span[contains(text(), 'Hasło powinno mieć minimum 6 znaków.')]"
    _password_textbox = 'password'
    _empty_password_message = "//span[contains(text(), 'Podaj hasło.')]"
    _register_button = "//button[@type='submit']"
    _empty_terms_checkbox = "//span[contains(text(), 'Zaakceptuj regulamin.')]"
    _accept_terms_checkbox = "termsOfUseAcceptation"
    _marked_invalid_textbox = "div[contains(@class, 'invalid')]"
    _marked_valid_textbox = "div[@class='marked valid']"

    def __init__(self, driver):
        self.driver = driver
        super().__init__(driver)

    def enter_name(self, name):
        self.element_send_keys(name, self._name_testbox, locator_type='id')

    def enter_last_name(self, last_name):
        self.element_send_keys(last_name, self._last_name_testboc, locator_type='id')

    def enter_password(self, password):
        self.element_send_keys(password, self._password_textbox, locator_type='id')

    def enter_email(self, email):
        self.element_send_keys(email, self._email_textbox, locator_type='id')

    def accept_terms_checkbox(self):
        self.element_click(self._accept_terms_checkbox, locator_type='id')

    def click_on_register_button(self):
        self.element_click(self._register_button, locator_type='xpath')

    def verify_marked_invalid_form(self, locator):
        marked_invalid_form = self.is_element_present(locator+'/preceding-sibling::'+self._marked_invalid_textbox, locator_type='xpath')
        assert marked_invalid_form == True,'Textbox is not marked as invalid'

    def verify_valid_form(self, locator):
        marked_valid_form = self.is_element_present("//input[contains(@id, '{}')]".format(locator)+'/parent::'+self._marked_valid_textbox, locator_type='xpath')
        assert marked_valid_form == True,'Textbox is nor marked as valid'

    def verify_empty_name_message(self):
        empty_name_message_exsists = self.is_element_visible(self._empty_name_message, locator_type='xpath')
        assert empty_name_message_exsists == True,'Cannot find "Podaj imie." message'

    def verify_empty_name(self):
        self.verify_empty_name_message()
        self.verify_marked_invalid_form(self._empty_name_message)

    def verify_empty_last_name_message(self):
        empty_name_message_exsists = self.is_element_visible(self._empty_last_name_message, locator_type='xpath')
        assert empty_name_message_exsists == True,'Cannot find "Podaj nazwisko." message'

    def verify_empty_last_name(self):
        self.verify_empty_last_name_message()
        self.verify_marked_invalid_form(self._empty_last_name_message)

    def verify_empty_email_message(self):
        empty_name_message_exsists = self.is_element_visible(self._empty_email_message, locator_type='xpath')
        assert empty_name_message_exsists == True,'Cannot find "Podaj adres e-mail." message'

    def verify_empty_email(self):
        self.verify_empty_email_message()
        self.verify_marked_invalid_form(self._empty_email_message)

    def verify_incorrect_email_address_message(self):
        incorrect_email_message_exists = self.is_element_visible(self._incorrect_email_address, locator_type='xpath')
        assert incorrect_email_message_exists == True,'Cannot find "Podaj prawidłowy adres e-mail." message'

    def verify_incorrect_email(self):
        self.verify_incorrect_email_address_message()
        self.verify_marked_invalid_form(self._incorrect_email_address)

    def verify_email(self, email):
        result = re.match('^[_a-z0-9-]+(\\.[_a-z0-9-]+)*@[a-z0-9-]+(\\.[a-z0-9-]+)*(\\.[a-z]{2,4})$', email)
        print(result)
        if not result:
            self.verify_incorrect_email()
        else:
            self.verify_valid_form(self._email_textbox)

    def verify_too_short_password_message(self):
        too_short_password_message = self.is_element_visible(self._too_short_password_message, locator_type='xpath')
        assert too_short_password_message == True,'Cannot find "Hasło powinno mieć minimum 6 znaków." message'

    def verify_empty_password_message(self):
        empty_name_message_exsists = self.is_element_visible(self._empty_password_message, locator_type='xpath')
        assert empty_name_message_exsists == True,'Cannot find "Podaj haslo." message'

    def verify_empty_password(self):
        self.verify_empty_password_message()
        self.verify_marked_invalid_form(self._empty_password_message)

    def verify_too_short_password(self):
        self.verify_too_short_password_message()
        self.verify_marked_invalid_form(self._too_short_password_message)

    def verify_empty_tersm_message(self):
        empty_terms_message_exsists = self.is_element_visible(self._empty_terms_checkbox, locator_type='xpath')
        assert empty_terms_message_exsists == True,'Cannot find "Zaakceptuj regulamin." message'

    def verify_form_fields_message(self, name='', last_name='', password='', email='', accept_terms=False):
        if not name:
            self.verify_empty_name()
        else:
            self.verify_valid_form(self._name_testbox)

        if not last_name:
            self.verify_empty_last_name()
        else:
            self.verify_valid_form(self._last_name_testboc)

        if not password:
            self.verify_empty_password()
        elif len(password) < 6:
            self.verify_too_short_password()
        else:
            self.verify_valid_form(self._password_textbox)

        if not email:
            self.verify_empty_email()
        else:
            self.verify_email(email)

        if not accept_terms:
            self.verify_empty_tersm_message()

    def fill_register_form(self, name='', last_name='', password='', email='', accept_terms=False):
        self.enter_name(name)
        self.enter_last_name(last_name)
        self.enter_email(email)
        self.enter_password(password)
        if accept_terms:
            self.accept_terms_checkbox()

    def register(self, name='', last_name='', password='', email='', accept_terms=False):
        self.fill_register_form(name, last_name, password, email, accept_terms)
        self.click_on_register_button()
        self.verify_form_fields_message(name, last_name, password, email, accept_terms)
