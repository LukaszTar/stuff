from pages.courses.register_courses_page import RegisterCoursesPage
from utilities.status import Status
from utilities.read_data import read_data_from_csv
from pages.home.navigation_page import Navigate
from ddt import ddt, data, unpack
import unittest
import pytest
import time


@pytest.mark.usefixtures('oneTimeSetUp', 'setUp')
@ddt
class RegisterCoursesTests(unittest.TestCase):

    @pytest.fixture(autouse=True)
    def objectSetUp(self, oneTimeSetUp):
        self.courses = RegisterCoursesPage(self.driver)
        self.ts = Status(self.driver)
        self.nav = Navigate(self.driver)

    def setUp(self):
        self.nav.navigate_to_all_courses()

    @pytest.mark.run(order=1)
    @data(*read_data_from_csv('D:\\userdata\\targonsk\\Desktop\\python\\repo\\test_data.csv'))
    @unpack
    def test_invalid_enrollment(self, course_name, cc_num, cc_exp, cc_cvv, postal):
        self.courses.enter_course_name(course_name)
        time.sleep(2)
        self.courses.select_course_to_enroll(course_name)
        self.courses.enroll_course(cc_num, cc_exp, cc_cvv, postal)
        status = self.courses.verify_enroll_failed()
        self.ts.mark_final('ENROLLMENT_VERIFICATION', status, '## ENROLLMENT_VERIFICATION ##')
        self.courses.go_to_previous_page()
