import unittest
from tests.home.login_test import LoginTest
from tests.courses.register_courses_csv_data_tests import RegisterCoursesTests

tc1 = unittest.TestLoader().loadTestsFromTestCase(LoginTest)
tc2 = unittest.TestLoader().loadTestsFromTestCase(RegisterCoursesTests)

test_suite = unittest.TestSuite([tc1, tc2])

unittest.TextTestRunner(verbosity=2).run(test_suite)
